sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function (Controller, MessageToast,MessageBox) {
	"use strict";
	var objUser = {
		"Users": [{
			"userId": "",
			"candidateId": "",
			"name": "",
			"lastName": "",
			"dni": "",
			"photo": ""
		}]
	};
	return Controller.extend("maz_renfe.buscador_preferencias_candidato.controller.MainView", {
		onInit: function () {
			var oModelVisibilidad = new sap.ui.model.json.JSONModel({
				visible: false
			})
			this.getView().setModel(oModelVisibilidad, "jsonVisibilidad")

		},

		onSearch: function () {
			var usuarioABuscar = this.getView().byId("busqueda").getValue()
			var that = this
			this.getUserData(usuarioABuscar).then(function (apto, noapto) {
				if (apto == true) {
					that.getUserPhoto(usuarioABuscar).then(function (apto) {
						that.getUserCandidate(usuarioABuscar).then(function (apto) {
							if (apto == true) {
								sap.m.MessageBox.success('Candidato obtenido con Exito')
								console.log(objUser)
								var oModelUsuario = new sap.ui.model.json.JSONModel(); // Creacion del Modelo
								that.getView().setModel(oModelUsuario, "jsonUserModel");
								that.getView().getModel("jsonUserModel").setData(objUser);
							}
						})

					})
				}
			})

		},

		getUserPhoto: async function (usuarioABuscar) {
			return new Promise((resolve, reject) => {
				var path = '/odata/v2/Photo'
				$.ajax({
					url: path + "(photoType=11,userId='" + usuarioABuscar + "')",
					type: "GET",
					dataType: "json",
					headers: {
						"DataServiceVersion": "2.0",
						"X-CSRF-Token": "Fetch",
						"Content-Type": "application/json; charset=utf-8"
					},
					async: true,
					success: function (result, status, response) {
						objUser.Users[0].photo = result.d.photo
						resolve(true)
					},
					error: function (oError) {
						objUser.Users[0].photo = ""
						resolve(false)
						sap.m.MessageToast.show('no photo')
					}
				})
			})
		},

		getUserData: async function (usuarioABuscar) {
			return new Promise((resolve, reject) => {
				var path = '/odata/v2/User'
				$.ajax({
					url: path + "(userId='" + usuarioABuscar + "')",
					type: "GET",
					dataType: "json",
					headers: {
						"DataServiceVersion": "2.0",
						"X-CSRF-Token": "Fetch",
						"Content-Type": "application/json; charset=utf-8"
					},
					async: true,
					success: function (result, status, response) {
						objUser.Users[0].name = result.d.firstName
						objUser.Users[0].lastName = result.d.lastName
						objUser.Users[0].userId = result.d.userId
						objUser.Users[0].dni = result.d.custom02
						resolve(true)
					},
					error: function (oError) {

						reject(false)
						sap.m.MessageToast.show('no User')
					}
				})
			})
		},

		getUserCandidate: async function (usuarioABuscar) {
			return new Promise((resolve, reject) => {
				var path = '/odata/v2/CandidateLight?$filter=usersSysId%20eq%20%27' + usuarioABuscar + '%27';
				$.ajax({
					url: path,
					type: "GET",
					dataType: "json",
					headers: {
						"DataServiceVersion": "2.0",
						"X-CSRF-Token": "Fetch",
						"Content-Type": "application/json; charset=utf-8"
					},
					async: true,
					success: function (result, status, response) {
						objUser.Users[0].candidateId = result.d.results[0].candidateId
						resolve(true)
					},
					error: function (oError) {
						reject(false)
						sap.m.MessageToast.show('no User')
					}
				})
			})
		},
		
		onSelectionChange: function(evento){
		var seleccionado = evento.getSource().getSelectedContexts().length
		var visibilidad = this.getView().getModel('jsonVisibilidad').getData()
		if(seleccionado == 1){
			visibilidad.visible = true
			this.getView().getModel("jsonVisibilidad").setData(visibilidad)
		}
		
		},
		
		navTo: function(evento){
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("preferencias", {
				id: objUser.Users[0].candidateId
			})
		}

	});
});