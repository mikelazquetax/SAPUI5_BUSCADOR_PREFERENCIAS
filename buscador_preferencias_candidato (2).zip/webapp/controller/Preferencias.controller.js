sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ui/core/UIComponent",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox"
], function (Controller, History, UIComponent, Filter, FilterOperator, MessageBox) {
	"use strict";
	var objPref = {
		"preferencias": [{
			"CANDIDATEID": "",
			"FULLNAME": "",
			"CANDIDATUREID": "",
			"PLAZA": "",
			"ORDEN": "",
			"LAST_DATE": "",
			"TITULO": ""
		}]
	}

	var objeto = {
		"CANDIDATEID": "",
		"FULLNAME": "",
		"CANDIDATUREID": "",
		"PLAZA": "",
		"ORDEN": "",
		"TITULO": ""
	}

	return Controller.extend("maz_renfe.buscador_preferencias_candidato.controller.Preferencias", {
		onNavBack: function () {
			var oHistory = sap.ui.core.routing.History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);

			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("MainView");

			}
		},
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this)
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.getRoute("preferencias").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function (oEvent) {
			return new Promise((resolve, reject) => {

				var modeloInstanciado = this.getView().getModel('preferencias')
				if (modeloInstanciado) {
					modeloInstanciado.setData(null)
				}
				this.idJobApplication = window.decodeURIComponent(oEvent.getParameter('arguments').id);
				this.getView().setBusy(true)
				var that = this
				this.getDataFromHana(this.idJobApplication).then(function (apto) {
					if (apto == true) {

						that.getView().setBusy(false)
					} else {
						that.getView().setBusy(false)
						sap.m.MessageBox.error('error')
					}
				});
				resolve(true)
				that.getView().setBusy(false)
			})
		},
		getDataFromHana: async function (idjobApplication) {
			return new Promise((resolve, reject) => {
				var modelHana = this.getView().getModel("renfe_hana")
				var that = this
				modelHana.read('/ZrcmpreferenciascandidatointernoSet', {
					filters: [
						new Filter("CANDIDATEID", FilterOperator.EQ, idjobApplication),
					],
					async: true,
					success: function (oData, response) {
						console.log('ok')

						var oJsonModel = new sap.ui.model.json.JSONModel;

						objPref.preferencias.pop()

						objPref.preferencias = []
						objPref.preferencias.pop()

						oData.results.forEach((record) => {
							objeto.CANDIDATEID = record.CANDIDATEID
							objeto.FULLNAME = record.FULLNAME
							objeto.CANDIDATUREID = record.CANDIDATUREID
							objeto.PLAZA = record.PLAZA
							objeto.ORDEN = parseInt(record.ORDEN) + 1
							objeto.LAST_DATE = record.LAST_DATE

							objPref.preferencias.push(objeto)

							objeto = {}

						})

						objPref.preferencias.forEach((objeto) => {
							that.getNames(objeto.CANDIDATUREID).then(function (jobTitle) {
								if (jobTitle) {
									objeto.TITULO = jobTitle
									that.getView().setModel(oJsonModel, "preferencias")
									that.getView().getModel("preferencias").setData(objPref);
								}
							})
						})

						resolve(true)
					},
					error: function (oError) {
						console.log('notok')
						resolve(false)
					}
				})
			})
		},
		getNames: async function (CANDIDATUREID) {
			return new Promise((resolve, reject) => {
				var pathJR = "/odata/v2/JobApplication"
				var idCandidatura = '(' + CANDIDATUREID + 'L)'

				$.ajax({
					url: pathJR + idCandidatura + '/jobRequisition/jobReqLocale',
					type: "GET",
					dataType: "json",
					headers: {
						"DataServiceVersion": "2.0",
						"X-CSRF-Token": "Fetch",
						"Content-Type": "application/json; charset=utf-8"
					},
					async: true,
					success: function (result, status, response) {
						var jobTitle = result.d.results[0].jobTitle
						resolve(jobTitle)
					},
					error: function (oError) {
						resolve(false)
					}

				})
			})
		}
	});
});