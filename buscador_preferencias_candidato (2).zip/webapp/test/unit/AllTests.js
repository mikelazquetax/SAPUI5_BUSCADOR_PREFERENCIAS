sap.ui.define([
	"maz_renfe/buscador_preferencias_candidato/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});