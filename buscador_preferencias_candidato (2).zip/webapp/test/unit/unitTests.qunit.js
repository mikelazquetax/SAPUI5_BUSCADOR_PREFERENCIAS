/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"maz_renfe/buscador_preferencias_candidato/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});